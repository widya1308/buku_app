import 'package:flutter/material.dart';
import 'package:buku_app/services/api_service.dart';
import 'package:buku_app/models/buku.dart';
import 'package:buku_app/pages/tambah_buku_page.dart';

class BukuListPage extends StatefulWidget {
  const BukuListPage({super.key});

  @override
  State<BukuListPage> createState() => _BukuListPageState();
}


class _BukuListPageState extends State<BukuListPage> {
  late Future<List<Buku>> data;

  @override
  void initState() {
    super.initState();
    data = ApiService.getBuku();
  }

  void refresh() {
    setState(() {
      data = ApiService.getBuku();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Data Buku"),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => TambahBukuPage()),
          );
          refresh();
        },
        child: const Icon(Icons.add),
      ),
      body: FutureBuilder<List<Buku>>(
        future: data,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return const Center(
              child: Text("Gagal memuat data buku"),
            );
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(
              child: Text("Data buku masih kosong"),
            );
          }

          return ListView.builder(
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              final buku = snapshot.data![index];
              return Card(
                margin: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 6,
                ),
                child: ListTile(
                  title: Text(buku.judul),
                  subtitle: Text(buku.pengarang),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () async {
                      await ApiService.hapusBuku(buku.idbuku);
                      refresh();
                    },
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
