import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:buku_app/models/buku.dart';

class ApiService {
  static const String baseUrl = "http://10.0.2.2:8000/api";

  // LOGIN
  static Future<bool> login(String email, String password) async {
    final res = await http.post(
      Uri.parse("$baseUrl/login"),
      body: {
        "email": email,
        "password": password,
      },
    );
    return res.statusCode == 200;
  }

  // REGISTER
  static Future<bool> register(
      String name, String email, String password) async {
    final res = await http.post(
      Uri.parse("$baseUrl/register"),
      body: {
        "name": name,
        "email": email,
        "password": password,
      },
    );
    return res.statusCode == 200;
  }

  // GET DATA BUKU
  static Future<List<Buku>> getBuku() async {
    final res = await http.get(Uri.parse("$baseUrl/buku"));

    if (res.statusCode == 200) {
      final List data = json.decode(res.body);
      return data.map((e) => Buku.fromJson(e)).toList();
    } else {
      throw Exception("Gagal mengambil data buku");
    }
  }

  // TAMBAH BUKU  ✅ (INI YANG TADI HILANG)
  static Future<void> tambahBuku(
      String id,
      String judul,
      String pengarang,
      String penerbit,
      ) async {
    await http.post(
      Uri.parse("$baseUrl/buku"),
      headers: {"Content-Type": "application/json"},
      body: json.encode({
        "idbuku": id,
        "judul": judul,
        "pengarang": pengarang,
        "penerbit": penerbit,
      }),
    );
  }

  // HAPUS BUKU  ✅ (INI YANG TADI HILANG)
  static Future<void> hapusBuku(String id) async {
    await http.delete(
      Uri.parse("$baseUrl/buku/$id"),
    );
  }
}
